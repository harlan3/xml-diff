function getFullTextContent() {
  var fullText = [  {"name": "Home","id": "_index_","meta": "This tool allows to present a diff between XML files","url": "index.html"},
  {"name": "Configuration","id": "configuration","meta": "This article presents the configuration of the comparison","url": "articles/article_config.html"},
  {"name": "xmldiffGUI","id": "xmldiffgui","meta": "This article presents the application which you can use directly","url": "articles/article_xmldiffgui.html"},
  {"name": "Application options","id": "application_options","meta": "This article presents the options of the application","url": "articles/article_appoptions.html"},
  {"name": "Comparison result","id": "comparison_result","meta": "This article presents the result of the comparison in the diff window","url": "articles/article_comparisonresult.html"},
  {"name": "Default comparison","id": "default_comparison","meta": "This article presents the default comparison algorithm","url": "articles/article_defaultcomp.html"},
  {"name": "Distribution","id": "distribution","meta": "This article presents the distribution of the xmldiff tool","url": "articles/article_distribution.html"},
  {"name": "Names tutorial","id": "names_tutorial","meta": "This article presents a tutorial with rules configuration dealing with nodes names","url": "articles/article_tutorial2.html"},
  {"name": "Dependencies","id": "dependencies","meta": "This article presents the dependencies of the xmldiff tool","url": "articles/article_dependencies.html"},
  {"name": "Description attributes","id": "description_attributes","meta": "This article presents the description attributes in the configuration of the comparison","url": "articles/article_descriptionattr.html"},
  {"name": "Show in File","id": "show_in_file","meta": "This article presents the Show in File action on the comparison result","url": "articles/article_showinfile.html"},
  {"name": "License","id": "license","meta": "License","url": "articles/article_license.html"},
  {"name": "Second names tutorial","id": "second_names_tutorial","meta": "This article presents a tutorial with rules configuration with more than one rule","url": "articles/article_tutorial3.html"},
  {"name": "CDATA content","id": "cdata_content","meta": "This article presents the configuration of the CDATA comparison for a RUle","url": "articles/article_cdata.html"},
  {"name": "Tutorials","id": "tutorials","meta": "This article presents the list of tutorials","url": "articles/article_tutorials.html"},
  {"name": "Basic tutorial","id": "basic_tutorial","meta": "This article presents a first basic tutorial with very simple rules configuration","url": "articles/article_tutorial1.html"},
  {"name": "xmldiff library","id": "xmldiff_library","meta": "This article presents the library which you can include in your own application","url": "articles/article_xmldifflib.html"},
  {"name": "Algorithm","id": "algorithm","meta": "This article presents the algorithm of the comparison","url": "articles/article_algorithm.html"}]
  return fullText;
}